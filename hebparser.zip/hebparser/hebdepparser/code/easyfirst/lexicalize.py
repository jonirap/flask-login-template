## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    HebDepParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebDepParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebDepParser.  If not, see <http://www.gnu.org/licenses/>.

def lexicalize(tok):
   if tok['tag'] in ['PRP','COP','PREPOSITION']:
      tok['tag']="%s~%s" % (tok['tag'],tok['form'])

def lexicalize_sent(sent,lexf=lexicalize):
   for tok in sent: lexf(tok)
