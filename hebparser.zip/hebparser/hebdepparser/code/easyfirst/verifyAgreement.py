## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    HebDepParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebDepParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebDepParser.  If not, see <http://www.gnu.org/licenses/>.

from pio import io
from common import ROOT,PAD
import sys

#{{{
ROOT['def']='-'
PAD['def']='-'
ROOT['morph']=['_']
PAD['morph']=['_']

def is_male(morph):
   return 'M' in morph or 'B' in morph
def is_female(morph):
   return 'F' in morph or 'B' in morph
def is_single(morph):
   return 'S' in morph
def is_plural(morph):
   return 'P' in morph or 'D' in morph

def agree_g(m1,m2):
   if '_' in m1 or '_' in m2: return True
   if is_male(m1) and is_male(m2):
      return True
   if is_female(m1) and is_female(m2):
      return True
   return False

def agree_n(m1,m2):
   if '_' in m1 or '_' in m2: return True
   if is_single(m1) and is_single(m2):
      return True
   if is_plural(m1) and is_plural(m2):
      return True
   return False

PERSONAL_PRONOUNS=set("ANI ATH AT HWA HIA HM HN ANZXNW ANW ATM ATN".split())
DEMONSTRATIVES=set("ZH ZW ZAT ALW HLLW KLFHW KLFHM KLFHN".split())
PAST_COP=set("HIH HITH HIITH HIW HIINW HIIT HIITI".split())
FUTURE_COP=set("IHIH TIHIH THIH IHIW NHIH THIINH".split())

#}}}
def verify_agreement(par,chl,sent):
   pm=par['morph']
   cm=chl['morph']
   pf=par['form']
   cf=chl['form']
   if par['tag'][0]=='N' and chl['tag'][0]=='J':
      if not agree_n(pm,cm): print "nj n disagree",pm,cm,pf,cf
      return
      if not agree_g(pm,cm): print "nj g disagree",pm,cm,pf,cf
      return
   elif par['tag'][0]=='J' and chl['tag'][0]=='J':
      if not agree_n(pm,cm): print "jj n disagree",pm,cm,pf,cf
      return
      if not agree_g(pm,cm): print "jj g disagree",pm,cm,pf,cf
      return
   elif par['tag'][0]=='N' and (chl['tag']=='PRP' and chl['form'] in DEMONSTRATIVES) and chl['id']>par['id']:
      if not agree_n(pm,cm): print "nd n disagree",pm,cm,pf,cf
      return
      if not agree_g(pm,cm): print "nd g disagree",pm,cm,pf,cf
      return

   if chl['id']<par['id']:
      if chl['tag'][0]=='N' and par['tag'] in ['VB','BN']:
         if not agree_n(pm,cm): print "sv? n disagree",pm,cm,pf,cf
         if not agree_g(pm,cm): print "sv? g disagree",pm,cm,pf,cf
      if chl['tag'][0]=='N' and par['tag'] in ['MD']:
         if not agree_n(pm,cm): print "sm? n disagree",pm,cm,pf,cf
         if not agree_g(pm,cm): print "sm? g disagree",pm,cm,pf,cf
      if chl['tag']=='PRP' and par['tag'] in ['VB','BN','MD'] and chl['form'] in PERSONAL_PRONOUNS:
         if not agree_n(pm,cm): print "spp? n disagree",pm,cm,pf,cf
         if not agree_g(pm,cm): print "spp? g disagree",pm,cm,pf,cf

for sent in io.conll_to_sents(sys.stdin):
   #print "sent"
   toks={0:ROOT}
   for tok in sent:
      toks[tok['id']]=tok
   for tok in sent:
      par = toks[tok['parent']]
      chl = tok
      verify_agreement(par,chl,sent)
