## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    HebDepParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebDepParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebDepParser.  If not, see <http://www.gnu.org/licenses/>.

def annotate_morph(sent):
   for tok in sent:
      if tok['tag'] == 'NNP': tok['def']='Y'
      elif tok['tag'] == 'DEF': tok['def']='Y'
      #elif tok['tag'] == 'CDT': tok['def']='Y'  # new
      elif tok['tag'] == 'NNT': tok['def']='M'
      #elif tok['tag'] == 'JJT': tok['def']='M'  # new
      elif tok['tag'][0] in 'NJ': tok['def']='M'
      elif tok['tag'] == 'CONJ': tok['def']='A'
      else: tok['def']='-'
   #for tok1,tok2 in zip(sent,sent[1:]):
   #   if tok1['form'] in ('PXWT','IWTR') and tok2['form']=='M':
   #      tok1['tag']=tok1['ctag']='PXWTM1'
   #      tok2['tag']=tok2['ctag']='PAXTM2'

def update_morph(parent,child,deps=None):
   if parent['form']=='F':
      if child['tag'] in ['VB','BN']:
         #print "F:",child['tag'],child['form'],(deps.left_child(child)['prel'],deps.left_child(child)['tag']) if deps.left_child(child) else None
         lc=deps.left_child(child)
         if lc and lc['tag'][0] in 'NP': pass
         else:
            #print "before:",parent['morph'],
            parent['morph'].extend(child['morph'])
            #print "after:",parent['morph']

   if parent['def']=='-': return
   if child['def']=='Y': parent['def']='Y'
   if child['def']=='M' and parent['tag']=='CONJ': parent['def']='M'
   if parent['tag']=='CONJ' and (not parent['morph']) and child['tag'][0] in ['NVJMB']: 
         parent['morph']=child['morph']

      
