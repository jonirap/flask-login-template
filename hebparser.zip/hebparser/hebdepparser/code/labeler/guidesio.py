## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    HebDepParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebDepParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebDepParser.  If not, see <http://www.gnu.org/licenses/>.

def read_guides(base_name, guide_names):
   '''
   return:
   an iteration of dictionaries mapping guide_names to sent
   each item in the iteration is
   {'parser_a' : sent1parseda,
    'parser_b' : sent1parsedb,
    ...}

   '''
   guides = {}
   for g in guide_names:
      fname = "%s.%s" % (base_name, g)
      sents = list(io.conll_to_sents(file(fname)))
      guides[g]=sents
   names_sents = guides.items()
   names = [n  for n,ss in names_sents]
   sents = [ss for n,ss in names_sents]
   for parses in zip(*sents):
      d = dict(zip(names,parses))
      yield d
   #return guides

