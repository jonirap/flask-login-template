#!/usr/bin/env python
## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    HebDepParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebDepParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebDepParser.  If not, see <http://www.gnu.org/licenses/>.

import codecs
import sys

from optparse import OptionParser
parser = OptionParser("%prog [options] < in_file > out_file")
parser.add_option("-i","--ie",help="input encoding [default %default]",dest="in_enc",default="utf_8_sig")
parser.add_option("-o","--oe",help="output encoding [default %default]",dest="out_enc",default="utf_8")
parser.add_option("-f","--fix_punct",help="add sentence-final period if missing",dest="add_final_period",action='store_true', default=False)
opts, args = parser.parse_args()

for line in codecs.getreader(opts.in_enc)(sys.stdin):
   line = line.strip().replace(". ",".\n").replace("? ","?\n").replace("! ","!\n")
   sents = line.split("\n")
   for sent in sents:
      sent = sent.strip()
      if sent: 
         if opts.add_final_period and sent[-1] not in u'.,?!;:': 
            print sent.encode(opts.out_enc),u"."
         else:
            print sent.encode(opts.out_enc)



