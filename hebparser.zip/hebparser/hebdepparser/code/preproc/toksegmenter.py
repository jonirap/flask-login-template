#!/usr/bin/python
#coding:utf8
## Copyright 2010 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    see GPLv3.LICENSE under the main folder for license terms.
##
import sys
import os
import os.path
from collections import defaultdict
import codecs


def _anal_to_tag_seq(tag):
   if ":S_PP" in tag: tag = tag.replace(":S_PP","/S_PP")+":"
   res = []
   pref,main,suf=tag.strip().split(":")
   for p in pref.split("+"):
      if p: res.append(p)
   res.append(main)
   if suf:
      #if suf.split("-")[0] in DUMMIES:
      #   res.append("AWT")
      res.append(suf)
   return res

class DepTreebankTokenSegmenter:
   @classmethod
   def create(cls, lang="heb",basedir=".",remove_hidden_h=True):
      prefixer = Prefixer.create(lang,basedir,remove_hidden_h)
      suffixer = DepTbSuffixer.create()
      return cls(prefixer,suffixer)

   def __init__(self, prefixer,suffixer):
      self._prefixer=prefixer
      self._suffixer=suffixer

   def segment(self, token, tag, lemma=None):
      """
      token: "BBITW"
      anal: "PREPOSITION:NN-M-S:S_PP-M-S-3"

      return: [('PREPOSITION','B'), ('NN-M-S/S_PP-M-S-3','BITW')]

      ====
      
      token: "WFAIN"
      anal:  "CONJ+REL-SUBCONJ:EX:"

      return: [('CONJ','W'),('REL-SUBCONJ','F'),('EX','AIN')]

      """
      if token==u'שכאמור':
         return ('REL-SUBCONJ','PREPOSITION','MD-M-S-A'),(u'ש',u'כ',u'אמור')
      if token==u'שלאורך':
         return ('REL-SUBCONJ','PREPOSITION','NNT-M-S'),(u'ש',u'ל',u'אורך')
      if token==u'וכדומה':
         return ('CONJ','PREPOSITION','JJ-M-S'),(u'ו',u'כ',u'דומה')
      if token==u'ככזה':
         return ('PREPOSITION','PREPOSITION','PRP-M-S-3'),(u'כ',u'כ',u'זה')



      if token==u'הכל' and tag=='DEF:DT:' or tag==':DEF@DT:':
         return ('DEF@DT',),(u'הכל',)
      if "^U^" in tag:
         tag1,tag2 = tag.split("^U^")
         tok1,tok2 = token.split('"',1)
         a1,p1 = self.segment(tok1,tag1)
         a2,p2 = self.segment(tok2,tag2)
         a1=tuple([x for x in a1 if x])
         a2=tuple([x for x in a2 if x])
         p1=tuple([x for x in p1 if x])
         p2=tuple([x for x in p2 if x])
         return a1+('PUNC',)+a2,p1+('"',)+p2  # TODO: " or U

      if "@" in tag: 
         tag=tag.replace("@",":")
         if tag[0]==":": tag=tag[1:]
      if tag.startswith("!!"):
         return tag.split(":"),tag.split(":") # !!MISS!!,!!UNK!! -- don't deal @@
      prefs,pref_tags,rest = self._prefixer.get_prefix(token,tag,lemma)
      #print rest,tag
      main,suffs,suff_tags = self._suffixer.get_suffix(rest,tag)

      if ":S_PP" in tag: tag = tag.replace(":S_PP","/S_PP")+":"
      #print tag, pref_tags, suff_tags
      return pref_tags+(tag.split(":")[1],)+suff_tags, prefs+(main,)+suffs
      
 
class Prefixer: #{{{
   @classmethod
   def create(cls,lang="heb", basedir=".", remove_hidden_h=True):
      prefixes_file=os.path.join(basedir,"bgupreflex.utf8.hr")
      #trans = translate.heb2tb if lang=='tb' else lambda x:x
      lex   = defaultdict(list)
      morph = defaultdict(list)
      for line in codecs.open(prefixes_file,"r","utf8"):
         pref,anals = line.split(None,1)
         #pref=trans(pref)
         anals = iter(anals.split())
         while True:
            try:
               #hidden_h=False
               #seq = tuple(trans(anals.next()).split("^"))
               seq =  tuple(      anals.next() .split("^"))
               #if remove_hidden_h and translate.heb2tb(seq[-1])=='H' and pref[-1]!=seq[-1]: 
               #   seq = seq[:-1]
               #   hidden_h=True
               anal= anals.next()
               assert(anal.endswith("::"))
               anal = anal.replace("::","")
               tags = anal.split("+")
               if remove_hidden_h and len(tags)>1 and tags[-1]=='DEF' and tags[-2]=='PREPOSITION' and seq[-2] in [u'ל',u'ב',u'כ'] and seq[-1]==u'ה':
                  #print "remove hidden h",seq,tags
                  seq = seq[:-1]
                  tags = tags[:-1]
                  if pref[-1]=='H':
                     pref = pref[:-1]
               lex[pref].append((seq,anal))
               morph[anal].append((pref,seq,tuple(tags)))
            except StopIteration: break
      # add the empty case
      morph['']=[('',tuple(),tuple())]
      morph['PREPOSITION'].append((u'כש',(u'כש',),('PREPOSITION',)))
      morph['REL']=[(u'ה',(u'ה',),('REL',))]
      lex['']=[(tuple(),'')]
      for key in morph: # sort the lists for each prefix in decreasing suffix length sorder
         morph[key]=sorted(morph[key],key=lambda v:-len(v[0]))
      return cls(dict(morph),dict(lex))

   def __init__(self,tags_to_letters,letters_to_tags):
      self.tags_to_letters = tags_to_letters
      self.letters_to_tags = letters_to_tags


   def get_prefix(self, token, anal,lemma=None):
      if lemma and lemma[0]=='!': lemma=None
      if lemma and lemma[0]=='?': lemma=None
      pref_tag = anal.split(":")[0]
      pref_tags=pref_tag.split("+") if pref_tag else []
      if lemma:
         pref_strs = [x for x in lemma.split(":")[0].split("^") if x]
         pref_str = "".join(pref_strs)
         assert(len(pref_strs)==len(pref_tags)),[token,lemma,pref_strs,pref_tags]
         assert(token.startswith(pref_str)),[token,pref_str,pref_strs,pref_tags]
         main=token[len(pref_str):]
         return (tuple(pref_strs),tuple(pref_tags),main)

      possible_prefs = self.tags_to_letters[pref_tag]
      for (pref,seq,tag_seq) in possible_prefs:
         if token.startswith(pref):
            #print token,pref
            main = token[len(pref):]
            return (seq,tag_seq,main)
      assert(False),"should not get here"
   #}}}

#SPECIAL_CASES = { ('HKL','DEF:DT:') : #@@@TODO

SPECIAL_CASE_SUFFIXES = {
      (u'ממך','S_PRN-MF-S-2'): (u'מ',(u'אתה~',),('S_PRN-MF-S-2',)),
      (u'ממך','S_PRN-M-S-2'):  (u'מ',(u'אתה~',),('S_PRN-M-S-2',)),
      (u'ממך','S_PRN-F-S-2'): (u'מ',(u'את~',),('S_PRN-F-S-2',)),

      (u'אותם','S_PRN-MF-P-3'): (u'אות',(u'הם~',),('S_PRN-MF-P-3',)),
      (u'אותם','S_PRN-M-P-3'): (u'אות',(u'הם~',),('S_PRN-M-P-3',)),
      (u'אותן','S_PRN-F-P-3'): (u'אות',(u'הן~',),('S_PRN-F-P-3',)),

      (u'בעקבותיו','S_PRN-M-S-3'): (u'בעקבות',(u'הוא~',),('S_PRN-M-S-3',)),
      (u'בעקבותיב','S_PRN-F-S-3'): (u'בעקבות',(u'היא~',),('S_PRN-F-S-3',)),

      (u'כמוהו','S_PRN-M-S-3'): (u'כמו',(u'הוא~',),('S_PRN-M-S-3',)),
      (u'כמוה','S_PRN-F-S-3'): (u'כמו',(u'היא~',),('S_PRN-F-S-3',)),
      (u'כמוהם','S_PRN-M-P-3'): (u'כמו',(u'הם~',),('S_PRN-M-P-3',)),
      (u'כמוהן','S_PRN-F-P-3'): (u'כמו',(u'הם~',),('S_PRN-F-P-3',)),

      (u'אתם','S_PRN-MF-P-3'): (u'את',(u'הם~',),('S_PRN-MF-P-3',)), # TODO really?? AT? verify
      (u'אתם','S_PRN-M-P-3'): (u'את',(u'הם~',),('S_PRN-M-P-3',)),
      (u'אתם','S_PRN-F-P-3'): (u'את',(u'הן~',),('S_PRN-F-P-3',)),

      # %% for auto-tagged TB.
      (u'בהם','S_PRN-M-P-2') : (u'ב',(u'הם~',),('S_PRN-M-P-2',)),
      (u'בהן','S_PRN-F-P-2') : (u'ב',(u'הן~',),('S_PRN-F-P-2',)),
      ####

      (u'בהם','S_PRN-M-P-3') : (u'ב',(u'הם~',),('S_PRN-M-P-3',)),
      (u'בהן','S_PRN-F-P-3') : (u'ב',(u'הן~',),('S_PRN-F-P-3',)),
      (u'להם','S_PRN-M-P-3') : (u'ל',(u'הם~',),('S_PRN-M-P-3',)),
      (u'להן','S_PRN-F-P-3') : (u'ל',(u'הן~',),('S_PRN-F-P-3',)),
      (u'מהם','S_PRN-M-P-3') : (u'מ',(u'הם~',),('S_PRN-M-P-3',)),
      (u'מהן','S_PRN-F-P-3') : (u'מ',(u'הן~',),('S_PRN-F-P-3',)),
      (u'שלהם','S_PRN-M-P-3') : (u'של',(u'הם~',),('S_PRN-M-P-3',)),
      (u'שלהן','S_PRN-F-P-3') : (u'של',(u'הן~',),('S_PRN-F-P-3',)),
      (u'ביניהם','S_PRN-M-P-3') : (u'ביני',(u'הם~',),('S_PRN-M-P-3',)),
      (u'ביניהן','S_PRN-F-P-3') : (u'ביני',(u'הן~',),('S_PRN-F-P-3',)),
      (u'בינהם','S_PRN-M-P-3') : (u'ביני',(u'הם~',),('S_PRN-M-P-3',)),
      (u'בינהן','S_PRN-F-P-3') : (u'ביני',(u'הן~',),('S_PRN-F-P-3',)),
      (u'אליהם','S_PRN-M-P-3') : (u'אלי',(u'הם~',),('S_PRN-M-P-3',)),
      (u'אליהן','S_PRN-F-P-3') : (u'אלי',(u'הן~',),('S_PRN-F-P-3',)),
      (u'עליהם','S_PRN-M-P-3') : (u'עלי',(u'הם~',),('S_PRN-M-P-3',)),
      (u'עליהן','S_PRN-F-P-3') : (u'עלי',(u'הן',),('S_PRN-F-P-3',)),
      (u'לפניהם','S_PRN-M-P-3') : (u'לפני',(u'הם~',),('S_PRN-M-P-3',)),
      (u'לפניהן','S_PRN-F-P-3') : (u'לפני',(u'הן~',),('S_PRN-F-P-3',)),
      (u'אחריהם','S_PRN-M-P-3') : (u'אחרי',(u'הם~',),('S_PRN-M-P-3',)),
      (u'אחריהן','S_PRN-F-P-3') : (u'אחרי',(u'הן~',),('S_PRN-F-P-3',)),
      (u'מאחריהם','S_PRN-M-P-3') : (u'מאחורי',(u'הם~',),('S_PRN-M-P-3',)),
      (u'מאחריהן','S_PRN-F-P-3') : (u'מאחורי',(u'הן~',),('S_PRN-F-P-3',)),
      (u'לפיהם','S_PRN-M-P-3') : (u'לפי',(u'הם~',),('S_PRN-M-P-3',)),
      (u'לפיהן','S_PRN-F-P-3') : (u'לפי',(u'הן~',),('S_PRN-F-P-3',)),

      (u'עימם','S_PRN-M-P-3') : (u'עם',(u'הם~',),('S_PRN-M-P-3',)),
      (u'עימן','S_PRN-F-P-3') : (u'עם',(u'הן~',),('S_PRN-F-P-3',)),
      (u'עימו','S_PRN-M-S-3') : (u'עם',(u'הוא~',),('S_PRN-M-S-3',)),
      (u'עימה','S_PRN-F-S-3') : (u'עם',(u'היא~',),('S_PRN-F-S-3',)),

      (u'כלפיהם','S_PRN-M-P-3') : (u'כלפי',(u'הם~',),('S_PRN-M-P-3',)),
      (u'כלפיהן','S_PRN-F-P-3') : (u'כלפי',(u'הן~',),('S_PRN-F-P-3',)),

      (u'משלהם','S_PRN-M-P-3') : (u'משל',(u'הם~',),('S_PRN-M-P-3',)),
      (u'משלהן','S_PRN-F-P-3') : (u'משל',(u'הן~',),('S_PRN-F-P-3',)),
      (u'משלו','S_PRN-M-S-3') : (u'משל',(u'הוא~',),('S_PRN-M-S-3',)),
      (u'משלה','S_PRN-F-S-3') : (u'משל',(u'היא~',),('S_PRN-F-S-3',)),
}

SUFF_TO_STR = { #{{{
      'S_PP-MF-S-1': (u'י',u'אני~'),
      'S_AP-MF-S-1': (u'י',u'אני~'),
      'S_NP-MF-S-1': (u'י',u'אני~'),
      'S_PRN-MF-S-1': (u'י',u'אני~'),
      'S_ANP-MF-S-1': (u'י',u'אני~'),

      'S_PP-MF-S-2': (u'כ',u'אתה~'),
      'S_PP-M-S-2':  (u'כ',u'אתה~'),
      'S_PP-F-S-2':  (u'כ',u'את~'),
      'S_PRN-MF-S-2': (u'כ',u'אתה~'),
      'S_PRN-M-S-2': (u'כ',u'את~'),
      'S_PRN-F-S-2': (u'כ',u'את~'),
        
      'S_AP-MF-S-2': (u'כ',u'אתה~'),
      'S_AP-M-S-2': (u'כ',u'אתה~'),
      'S_AP-F-S-2': (u'כ',u'אתה~'),
        
      'S_NP-MF-S-2': (u'כ',u'אתה~'),
      'S_NP-M-S-2': (u'כ',u'אתה~'),
      'S_NP-F-S-2': (u'כ',u'אתה~'),

      'S_ANP-MF-S-2': (u'כ',u'אתה~'),
      'S_ANP-M-S-2': (u'כ',u'אתה~'),
      'S_ANP-F-S-2': (u'כ',u'אתה~'),
        
      'S_PP-M-S-3': (u'ו',u'הוא~'),
      'S_PRN-M-S-3': (u'ו',u'הוא~'),
      'S_AP-M-S-3': (u'ו',u'הוא~'),
      'S_NP-M-S-3': (u'ו',u'הוא~'),
      'S_ANP-M-S-3': (u'ו',u'הוא~'),

      'S_PP-F-S-3': (u'ה',u'היא~'),
      'S_PRN-F-S-3': (u'ה',u'היא~'),
      'S_AP-F-S-3': (u'ה',u'היא~'),
      'S_NP-F-S-3': (u'ה',u'היא~'),
      'S_ANP-F-S-3': (u'ה',u'היא~'),

      'S_PP-MF-P-1': (u'נו',u'אנחנו~'),
      'S_PRN-MF-P-1':(u'נו',u'אנחנו~'),
      'S_AP-MF-P-1': (u'נו',u'אנחנו~'),
      'S_NP-MF-P-1': (u'נו',u'אנחנו~'),
      'S_ANP-F-P-1':(u'נו',u'אנחנו~'),
      'S_ANP-MF-P-1':(u'נו',u'אנחנו~'),

      'S_PP-MF-P-3': (u'מ',u'הם~'),
      'S_PRN-MF-P-3':(u'מ',u'הם~'),
      'S_AP-MF-P-3': (u'מ',u'הם~'),
      'S_NP-MF-P-3': (u'מ',u'הם~'),
      'S_ANP-MF-P-3':(u'מ',u'הם~'),

      'S_NP-M-P-1': (u'נו',u'אנחנו~'),
      'S_NP-F-P-1': (u'נו',u'אנחנו~'),

      'S_PP-M-P-2': (u'כם',u'אתם~'),
      'S_PRN-M-P-2': (u'כם',u'אתם~'),
      'S_AP-M-P-2': (u'כם',u'אתם~'),
      'S_NP-M-P-2': (u'כם',u'אתם~'),
      'S_ANP-M-P-2': (u'כם',u'אתם~'),

      'S_PP-F-P-2': (u'כן',u'אתן~'),
      'S_PRN-F-P-2':(u'כן',u'אתן~'),
      'S_AP-F-P-2': (u'כן',u'אתן~'),
      'S_NP-F-P-2': (u'כן',u'אתן~'),
      'S_ANP-F-P-2':(u'כן',u'אתן~'),

      'S_PP-M-P-3': {'S':(u'מ',u'הם~'), 'P':(u'הם',u'הם~'), 'DP':(u'הם',u'הם~')},  # is base is Singular/Plural?

      'S_PRN-M-P-3': (u'מ',u'הם~'),

      'S_ANP-M-P-3': (u'מ',u'מם~'),
      'S_AN-M-P-3': (u'מ',u'מם~'),
      'S_ANP-M-P-3': (u'מ',u'מם~'),
      'S_PP-F-P-3': {'S':(u'ן',u'הן~'), 'P':(u'הן',u'הן~'), 'DP':(u'הן',u'הן~') },

      'S_PRN-F-P-3': (u'ן',u'הן~'),

      'S_AP-F-P-3': (u'ן',u'הן~'),
      'S_NP-F-P-3': (u'ן',u'הן~'),
      'S_ANP-F-P-3':(u'ן',u'הן~'),
}

DUMMIES = {
      '@@@@TODO': ('את','אות'),
      
      }

def _dummies(suf_tag):
   if suf_tag in DUMMIES:
      return DUMMIES[suf_tag.split("-")[0]]
   return ((),())

class DepTbSuffixer:
   @classmethod
   def create(cls):
      return cls()

   def __init__(self):
      pass
   

   def get_suffix(self, unprefixed, tag):
      """
      form w/o the prefix, tag --> form-wo-suffix, (suf_form0,...), (suf_tag0,...)
      """
      if ':S_PP' in tag: 
         tag=tag.replace(":S_PP","/S_PP")+":"
      ptag,mtag,stag=tag.split(":")
      if not stag:
         return unprefixed,tuple(),tuple()
      elif (unprefixed,stag) in SPECIAL_CASE_SUFFIXES:
         return SPECIAL_CASE_SUFFIXES[(unprefixed,stag)]
      else:
         sufs=[]
         suf_poses=[]
         fin,suf=SUFF_TO_STR[stag]
         if not unprefixed.endswith(fin):
            print >> sys.stderr, ("bad empirical suffix: %s %s" % (unprefixed, tag)).encode("utf8")
            return unprefixed,tuple(sufs),tuple(suf_poses)
            #assert(unprefixed.endswith(fin)),"bad empricial suffix: expected %s on %s" % (fin,unprefixed)
         dummy_pos,dummy_form=_dummies(stag)
         if dummy_pos: suf_poses.append(dummy_pos)
         if dummy_form:sufs.append(dummy_form)

         sufs.append(suf)
         suf_poses.append(stag)
         main=unprefixed[:-len(fin)]
         return main,tuple(sufs),tuple(suf_poses)


if __name__=='__main__':
   prefixer = Prefixer.create(lang="tb",basedir="../../lexicons/Hebrew/BguLex/data")
   print prefixer.get_prefix("BBIT","PREPOSITION+DEF::")
   print prefixer.get_prefix("BBIT","PREPOSITION+DEF::")
   print prefixer.get_prefix("BBIT","PREPOSITION:BLA:")
   print prefixer.get_prefix("WHRWXH","CONJ+DEF::")
   print prefixer.get_prefix("LHCMDH","PREPOSITION+DEF::")
   print prefixer.get_prefix("KFHQJIF","TEMP-SUBCONJ+DEF::")

   print prefixer.get_prefix("BBIT","PREPOSITION+DEF::","B:BIT")
   print prefixer.get_prefix("BBIT","PREPOSITION+DEF::","BIT")
   
