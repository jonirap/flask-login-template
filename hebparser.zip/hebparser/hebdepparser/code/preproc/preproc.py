#!/usr/bin/env python
#coding:utf8
## Copyright 2010 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    see GPLv3.LICENSE under the main folder for license terms.
##
import sys
import codecs
import os.path

HERE = os.path.dirname(__file__)
sys.path.append(os.path.join(HERE,""))
from toksegmenter import DepTreebankTokenSegmenter
import bgutags

segmenter = DepTreebankTokenSegmenter.create(basedir=HERE)

def normalize_lemmas(lemma, anal, token): #{{{
   """
   for all lemmas:
      prefix and lemma separated with ":", also when no prefix is there.
      non-hidden H is part of the prefix lemma
      hidden-H is removed, from both lemma and analysis
   return: anal,lemma
   """
   pref,base,suf = anal.split(":")
   prefs = [x for x in pref.split("+") if x]
   lemma=lemma.replace(u"ול^",u"ו^ל^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"וב^",u"ו^ב^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"וש^",u"ו^ש^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"ושב^",u"ו^ש^ב^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"וכ^",u"ו^כ^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"וכש^",u"ו^כש^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"ומש^",u"ו^מש^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"ומ^",u"ו^מ^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"שב^",u"ש^ב^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"של^",u"ש^ל^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"שמ^",u"ש^מ^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"בכ^",u"ב^כ^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"שכ^",u"ש^כ^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"לכ^",u"ל^כ^") # sometime this is not pre-split.. (Meni bug?)
   lemma=lemma.replace(u"מכ^",u"מ^כ^") # sometime this is not pre-split.. (Meni bug?)
   pref_strs = lemma.split(u"^")[:-1]

   if len(prefs)==len(pref_strs):
      pass
   elif len(prefs)==0 and len(pref_strs) > 0:
      # this is happening because of the PROPER-NAME indentifier overruling the tagger, but lemma unchanged..
      # no idea about why the second one happened..
      assert(anal==':NNP:' or anal==':PUNC-M-S:'),(token,anal,lemma)
      pref_strs=[]
   elif len(pref_strs)==0 and len(prefs)==1 and prefs[0]!='DEF':  # there is lemma only for prefix..(no base word)
      assert(token.startswith(lemma)),(lemma,token)
      pref_strs.append(lemma)
      #res=lemma+"^"
   elif len(prefs)-len(pref_strs)==1:
      assert(prefs[-1]=='DEF'),(token,prefs,pref_strs)
      if len(prefs)==1:
         pref_strs.append(u'ה')
      elif pref_strs[-1] in [u'ל',u'כ',u'ב'] and prefs[-2] in ['PREPOSITION']:
         # hidden h
         prefs=prefs[:-1]
      else:
         pref_strs.append(u'ה')
   assert(len(prefs)==len(pref_strs)),(prefs,pref_strs,token,lemma,anal)

   if prefs and prefs[-1]=='DEF':
      assert pref_strs[-1]==u'ה'
      if token[len("".join(pref_strs))-1]!=u'ה':
         #assert(base.startswith('NN')),(token,tpref_strs,anal,lemma)
         #sys.stderr.write( "removing DEF/H  %s\n" % ((token, pref_strs, anal, lemma),))
         prefs=prefs[:-1]
         pref_strs=pref_strs[:-1]

   assert(len(prefs)==len(pref_strs)),(prefs,pref_strs,token,lemma,anal)
   return ":".join(["+".join(prefs),base,suf]), "^".join(pref_strs)+":"+lemma
#}}}

def preproc_line(line):
   line = line.strip().split()
   if not line: return []
   print line
   if line:
      try:
         line[1] = bgutags.bm2tag(int(line[1]))
      except ValueError:
         print >> sys.stderr,"skipping bad line",line
         return
      anal,lemma = normalize_lemmas(line[2],line[1],line[0])
      line[1]=anal
      line[2]=lemma
      return line

def _kc_tag_splitter(tag): #{{{
   if tag == "!!MISS!!" or tag == "!!UNK!!":
      return tag,tag,tag
   if "/" in tag:
      tag, suff = tag.split("/")
      if not "-" in suff: suff+="-"
      suff, sfeats = suff.split("-",1)
      sfeats = sfeats.split("-")
      sfeats = ["suf_%s" % f for f in sfeats]
   else:
      sfeats = []
      suff = ''

   if not "-" in tag: tag = tag+"-"
   tag, feats = tag.split("-",1)
   ctag = tag
   if feats:
      feats = feats.split("-")
      if 'MF' in feats:
         feats.remove('MF')
         feats.append('M')
         feats.append('F')
      if 'SP' in feats:
         feats.remove('SP')
         feats.append('S')
         feats.append('P')
   else: feats=[""]
   if len(feats[0])>1: 
      tag = ctag + "-" + feats[0]
      feats = feats[1:]
   if suff: tag = tag + "_" + suff
   feats = "|".join(feats+sfeats)

   if not feats: feats = "_"
   return tag, ctag, feats
#}}}

def _fix_meni_tags(form, tag, ctag): #{{{
   ## NEG   --> RB / IN / P
   if tag == 'NEG':
      assert(ctag=='NEG')
      if form in [u'לא',u'אל',u'אין',u'לאו']:
         tag = 'RB'
         ctag= 'RB'
      elif form in [u'בלי']:
         tag = 'IN'
         ctag = 'IN'
      elif form in [u'בלתי',u'בל']:
         tag = 'P'
         ctag= 'P'
      else:
         assert(False),"NEG tag of unknown word %s" % (form)
      return (tag, ctag)

   ## EX-BEINONI  --> EX
   if ctag=='EX':
      assert(tag in ['EX','EX-BEINONI','EX-POSITIVE','EX-NEGATIVE']),tag
      #print >> sys.stderr, tag,form
      return ('EX','EX')

   ## DT-IREL, DTT-IREL --> DT / DTT
   if ctag in ['DT','DTT']:
      if tag.endswith('-IREL'):
         return (ctag,ctag)


   ## remove -IREL from all tags
   tag = tag.replace("-IREL","")
   
   return tag,ctag
#}}}

def _build_conll_line(id, form, pos, use_tb_punc=False): #{{{
      tag, ctag, morph = _kc_tag_splitter(pos)
      #if use_tb_punc:
      #   if form in translate.PUNCT_TO_TB: form = translate.PUNCT_TO_TB[form]
      tag,ctag = _fix_meni_tags(form,tag,ctag)
      return "\t".join([id,form,"_",ctag,tag,morph,"0","0","_","_"])
#}}}

def tokenize_blanks(stream):
   s=[]
   for line in stream:
      line = preproc_line(line)
      if line is None: continue
      if not line:
         if s: yield s
         s=[]
      else: s.append(line)
   if s: yield s

def yield_conlls(stream):
   for sent in tokenize_blanks(stream):
      snum=0
      for i,tok in enumerate(sent):
         form, anal, lemma, ner, chunk = tok
         if form in [u'הייה',u'איזו',u'איזושהי']: anal=":%s:" % anal.split(":")[1] # fixing a lexicon bug
         if form in [u'באיזושהי']: anal="%s:%s:" % (anal.split(":")[0],anal.split(":")[1])  # fixing a lexicon bug
         seg_poses, seg_forms = segmenter.segment(form, anal, lemma)
         seg_poses = (x for x in seg_poses if x)
         seg_forms = (x for x in seg_forms if x)
         for j,(spos,sform) in enumerate(zip(seg_poses,seg_forms)):
            snum+=1
            seg_conll_line = _build_conll_line("%s.%s" % (i+1,j), sform, spos, use_tb_punc=True)
            yield seg_conll_line
      yield "\n"
