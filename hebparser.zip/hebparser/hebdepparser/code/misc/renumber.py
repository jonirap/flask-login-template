#!/usr/bin/env python
## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    HebDepParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebDepParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebDepParser.  If not, see <http://www.gnu.org/licenses/>.

import sys
import os.path
from itertools import *
from collections import defaultdict
sys.path.append(os.path.join(os.path.dirname(__file__),"../easyfirst"))
from pio import io

def renumber(sent):
   fmap=defaultdict(count(1).next)
   fmap[0.0]=0
   fmap[-1]=-1
   for t in sent: t['id']=fmap[t['id']]
   for t in sent: t['parent']=fmap[t['parent']]

if __name__=='__main__':
   import codecs
   for sent in io.conll_to_sents(codecs.getreader("utf8")(sys.stdin)):
      renumber(sent)
      io.out_conll(sent)

