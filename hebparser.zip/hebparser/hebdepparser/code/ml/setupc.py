from distutils.core import setup, Extension

module1 = Extension('mlu',
		sources = ['mlu.c'])

setup (name = 'mlu',
		version = '1.0',
		ext_modules = [module1])

