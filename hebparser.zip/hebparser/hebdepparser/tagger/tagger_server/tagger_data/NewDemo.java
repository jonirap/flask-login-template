import java.util.List;
import java.util.Set;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;

import hebrewNER.NERTagger;
import vohmm.application.SimpleTagger2;
import vohmm.corpus.AnalProb;
import vohmm.corpus.Anal;
import vohmm.corpus.Corpus;
import vohmm.corpus.Sentence;
import vohmm.corpus.Sentence.OutputData;
import vohmm.corpus.Token;
import vohmm.corpus.Tag;
import vohmm.corpus.AffixInterface;
import vohmm.corpus.UnknownResolver;
import vohmm.corpus.AnalysisInterface;
import vohmm.corpus.BitmaskResolver;

public class Demo {
	
	public static void main(String[] args) {
		
		if (args.length != 3) {
			System.out.println("Usage: java -Xmx2G -cp trove-2.0.2.jar:XMLAnalyzer.jar:opennlp.jar:gnu.jar:tagger.jar:. Demo <tagger data directory> <in text file> <out>");
			System.exit(0);
		}
		try {
			// The follwoing object constructions are heavy - SHOULD BE APPLIED ONLY ONCE!
			// create the morphological analyzer and disambiguator 
			SimpleTagger3 tagger = new SimpleTagger3(args[0]);
			// create the named-entity recognizer
			NERTagger nerTagger = new NERTagger(args[0],tagger);
			// create the noun-phrase chunker (will be available soon in Java)
			//HebChunker chunker = new HebChunker(args[0]);

			// create input and output streams
			InputStream in = new FileInputStream(args[1]);
			PrintStream out = new PrintStream(new FileOutputStream(args[2]),false,"UTF-8");


			List<Sentence> taggedSentences = tagger.getTaggedSentences(in);
			for (Sentence sentence : taggedSentences) {
				out.println(sentence.toString(OutputData.TAGGED));
				// Alternatively, you can get each propery of the morphologuical tag of each word in  the given sentence by using AnalysisInterface, as follows:
				out.println("\nSame data can be retrieved by AnalysisInterface:");
				for (int i=0;i<sentence.size(); i++) {
					Token token = sentence.getToken(i);
					out.println(token.getOrigStr());
					Anal anal =  token.getSelectedAnal();
					out.println("\tLemma: " + anal.getLemma());

					// NOTE: In our tagger we consider participle of a 'verb' type as a present verb.
					// In order to adapt it to MILA's schema the last parameter of BitmaskResolver constructor should be 'false' (no present verb)
					AnalysisInterface bitmaskResolver = new BitmaskResolver(anal.getTag().getBitmask(),token.getOrigStr(),false);
					out.println("\tPOS: " + bitmaskResolver.getPOS());
					out.println("\tPOS type: " + bitmaskResolver.getPOSType()); // the type of participle is "noun/adjective" or "verb"
					out.println("\tGender: " + bitmaskResolver.getGender());
					out.println("\tNumber: " + bitmaskResolver.getNumber());
					out.println("\tPerson: " + bitmaskResolver.getPerson());
					out.println("\tStatus: " + bitmaskResolver.getStatus());
					out.println("\tTense: " + bitmaskResolver.getTense());
					out.println("\tPolarity: " + bitmaskResolver.getPolarity());
					out.println("\tDefiniteness: " + bitmaskResolver.isDefinite());
					if (bitmaskResolver.hasPrefix()) {
						out.print("\tPrefixes: ");
						List<AffixInterface> prefixes = bitmaskResolver.getPrefixes();
						for (AffixInterface prefix : prefixes)
							out.print(prefix.getStr() + " " + Tag.toString(prefix.getBitmask(),true) + " ");
						out.print("\n");
					} else
						out.println("\tPrefixes: None");
					if (bitmaskResolver.hasSuffix()) {
						out.println("\tSuffix Function: " + bitmaskResolver.getSuffixFunction());
						out.println("\tSuffix Gender: " + bitmaskResolver.getSuffixGender());
						out.println("\tSuffix Number: " + bitmaskResolver.getSuffixNumber());
						out.println("\tSuffix Person: " + bitmaskResolver.getSuffixPerson());
					} else 
						out.println("\tSuffix: None");					
				}
				// 4. Named-entiry recognition for the given tagged sentence
				// I_*   In expression
				// B_*   Begin of new expression
				// PERS - personal name
				// LOC - location
				// ORG - organization
				// DATE - date expression
				// TIME - time expression
				// PERCENT - percent expression
				// MONEY - money expression
				out.println("\n\nNamed-Entities:\n");
				out.println(nerTagger.tag(sentence));

				// 5. Noun-phrase chunking for the given tagged sentence (will be available soon in Java)
				//out.println(chunker.chunk(sentence));

				out.println("\n\n----------------------------------------------------------------------\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}    
}
