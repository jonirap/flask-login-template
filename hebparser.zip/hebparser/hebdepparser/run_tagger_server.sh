#!/bin/sh
TAGGER_DIR=tagger/tagger_server/
PORT=8089

java -Xmx1200m -XX:MaxPermSize=256m -server -jar ${TAGGER_DIR}/tagger_server_bm_lemma.jar ${PORT} ${TAGGER_DIR}/tagger_data/ pretokenize noChunk noNER
