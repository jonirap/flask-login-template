from parse import parse
def run_server():
    import os
    import subprocess
    devnull = open(os.devnull, 'wb')
    return subprocess.Popen(os.path.join(os.path.dirname(__file__), 'run_tagger_server.{}'.format('cmd' if os.name == 'nt' else 'sh')), shell=False, stdout=subprocess.PIPE, stderr=devnull)