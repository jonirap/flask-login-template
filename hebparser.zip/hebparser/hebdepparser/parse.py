#!/usr/bin/env python
## Copyright 2010 Yoav Goldberg
##
## This file is part of HebDepParser
##
##    see GPLv3.LICENSE under the main folder for license terms.
##

import copy
import sys
from collections import defaultdict
from itertools import count

import os.path
HERE = os.path.dirname(__file__)
import sys
sys.path.append(os.path.join(HERE,"code","easyfirst"))
import easyfirst
sys.path.append(os.path.join(HERE,"code","labeler"))
import eflabeler
sys.path.append(os.path.join(HERE,"code","preproc"))
import preproc
sys.path.append(os.path.join(HERE,"code","utils"))
import hebtokenizer
sys.path.append(os.path.join(HERE,"tagger"))
import tag

from pio import io
io.ID_TYPE=float
import time

def renumber(sent):
   fmap=defaultdict(count(1).next)
   fmap[0.0]=0
   fmap[-1]=-1
   for t in sent: t['id']=fmap[t['id']]
   for t in sent: t['parent']=fmap[t['parent']]
   for t in sent: t['pparent']=fmap[t['pparent']]


#PARSE_MODEL=os.path.join(HERE,"models","hebagr.sp5.model")
#LABEL_MODEL=os.path.join(HERE,"models","labeler.f6h.sp5.model.9")

#labeler = eflabeler.SimpleSentenceLabeler(eflabeler.Labeler.load(LABEL_MODEL), fext=eflabeler.AnEdgeLabelFeatureExtractor6Heb())
#parser = easyfirst.make_parser(PARSE_MODEL, "FINAL")

#reader = io.conll_to_sents

def parse_sent(sent, ip='localhost', OUTSTREAM=sys.stdout,tokenized=False):
   toks = sent.split() if tokenized else [tok for w,tok in hebtokenizer.tokenize(sent)]
   tagged = tag.get_tagged(' '.join(toks), ip)
   #print list(preproc.yield_conlls(tagged))
   #TEST_SENTS = reader(preproc.yield_conlls(tagged))
   #TEST_SENTS = list(TEST_SENTS); assert(len(TEST_SENTS)==1)
   #sent = TEST_SENTS[0]
   #deps=parser.parse(sent)
   #deps.annotate(sent)
   #renumber(sent)
   #labeler.label(sent, par='pparent',prelout='prel',sent_guides=None)
   #io.out_conll(sent,parent='pparent',out=OUTSTREAM)
   return tagged#sent
   
def word_list(parsed):
   lines = [line.split()[2] for line in parsed.split('\n') if len(line.split()) > 2]
   return [line.split('^')[1] if len(line.split('^')) > 1 else line for line in lines if len(line) > 1]
   
def parse(data, ip='localhost'):
    return word_list(parse_sent(data, ip))
   
#if __name__=='__main__':
   #import codecs
   #from cStringIO import StringIO
   #input = codecs.getreader('utf8')(sys.stdin)
   #tokenized='pretok' in sys.argv
   #parsed = parse_sent(open('sample.txt', 'rb').read())
   #data = '\n'.join(word_list(parsed))
   #open('a.txt', 'wb').write(data)
   #for line in input:
   #   parse_sent(line, sys.stdout, tokenized=tokenized)

