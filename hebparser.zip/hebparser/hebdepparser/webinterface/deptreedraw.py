import sys
import os.path
from itertools import count
HERE = os.path.dirname(__file__)
from collections import defaultdict


def tree_js(_sent,tid=1):
   out=["function createTree%s() {" % tid, "myTree = new ECOTree('myTree','myTreeContainer');", "myTree.config.useTarget=false; myTree.config.topXAdjustment=0; myTree.config.selectMode=ECOTree.SL_NONE; myTree.config.linkType='B'; "]
   create_js(_sent,out)
   out.append("myTree.UpdateTree(); }")
   return '\n'.join(out)

def create_js(_sent,out):
   children = defaultdict(list)
   for tok in _sent:
      children[tok['pparent']].append(tok)
   toks = [{'id':0,'pparent':-1,'form':'ROOT','prel':'ROOT','tag':'ROOT'}]
   while toks:
      tok = toks.pop()
      text = ("%s<br/>%s<br/><font color=gray>%s</font>" % (tok['prel'],tok['form'],tok['tag'])).replace('"',"''")
      out.append('myTree.add(%s,%s,"%s",-1,-1);' % (tok['id'],tok['pparent'],text))
      toks.extend(children[tok['id']])





