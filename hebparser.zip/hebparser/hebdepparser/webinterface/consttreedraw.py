import sys
import os.path
from itertools import count
HERE = os.path.dirname(__file__)
sys.path.append(os.path.join(HERE,'../code/pytrees'))
from tree import LingTree


def tree_js(treestring,tid=1):
   t=LingTree.from_str(u"(%s)" % treestring)
   cnt = count(0)
   out=["function createTree%s() {" % tid, "myTree = new ECOTree('myTree','myTreeContainer');", "myTree.config.useTarget=false; myTree.config.topXAdjustment=200"]
   create_js(t,cnt,out,-1)
   out.append("myTree.UpdateTree(); }")
   return '\n'.join(out)

def create_js(t,counter,out,parent):
   id = counter.next()
   text = "<span dir=rtl>%s</span>" % (t.name+"<br>"+t.as_sent().replace("yyLRB","(").replace("yyRRB",")").replace(u'"',u"''"))
   out.append('myTree.add(%s,%s,"%s",%s);' % (id,parent,text,-1)) #4*len(text)))
   if t.is_leaf():
      #out.append('myTree.add(%s,%s,"%s");' % (counter.next(),id,t.get_word()))
      pass
   else:
      for c in reversed(t.childs):
         create_js(c,counter,out,id)







