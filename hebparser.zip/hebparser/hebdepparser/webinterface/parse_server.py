#!/usr/bin/env python
#coding:utf8
from bottle import route, run, get, post, request, response, static_file
import bottle
bottle.debug(True)
import os.path
import codecs
from cStringIO import StringIO
from log import log

MAIN = os.path.join(os.path.dirname(__file__),"form.html")

HERE = os.path.dirname(__file__)

import sys
sys.path.append(os.path.join(HERE,".."))
from parse import parse_sent

import time
import deptreedraw

try:
   PORT=int(sys.argv[1])
except:
   PORT=8081

@route('/')
@get('/gparse')
def index():
   return file(MAIN).read()

@route('/static/:path#.+#')
def serve_static(path):
   return static_file(path,os.path.join(HERE,'static'))

@route('/img/:fname')
def serve_img(fname):
   return static_file(fname,os.path.join(HERE,'static/ecotree/img'))

@post('/parse')
def parse():
   response.content_type = 'text/plain'
   sent = request.forms.get("text")
   parsed = StringIO()
   _sent = parse_sent(unicode(sent,"utf8"),tokenized=False,OUTSTREAM=parsed)
   return parsed.getvalue()

@post('/gparse')
def gparse():
   sent = request.forms.get("text").decode("utf8")
   log("deprequests.log",request,sent)
   sents = sent.strip().replace(". ",".\n").replace("? ","?\n").replace("! ","!\n").split("\n")
   sent = sents[0]
   if len(sent.split())>60: sent=" ".join(sent.split()[:60])
   if sent[-1] not in u'.,?!;:': sent+=" ."
   parsed = StringIO()
   _sent = parse_sent(sent,tokenized=False,OUTSTREAM=parsed)
   return codecs.open(os.path.join(HERE,'mytree.htm'),encoding="utf8").read().replace('__BLA__', deptreedraw.tree_js(_sent)).replace('__SENT__',sent);

run(host='',port=PORT)
