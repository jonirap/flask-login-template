#!/bin/bash
cat - | ./code/utils/sentences.py -f --ie utf8 --oe utf8 | ./code/utils/hebtokenizer.py | ./parse.py pretok
