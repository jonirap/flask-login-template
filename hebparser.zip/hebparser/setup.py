from setuptools import setup, find_packages

setup(name='hebdepparser', packages=find_packages())